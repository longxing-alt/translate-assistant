// 网页翻译助手 - 核心逻辑 v1.1(原创)
// 功能:全页沉浸式翻译(Ctrl+F / F2)、输入框三连空格翻译成英文、
//      iframe/shadow DOM 全覆盖、调试侧边栏(Alt+T 查看状态与错误)
(() => {
  "use strict";
  if (window.__wtLoaded) return; // 防双注入(重载后自动补注入时,已有活脚本则直接退出)
  window.__wtLoaded = true;

  // 扩展重载/更新后,旧脚本 chrome.runtime 失效:自检失败时移除自己的监听器,让新脚本接管
  function ctxAlive() {
    try {
      return typeof chrome !== "undefined" && !!chrome.runtime && chrome.runtime.id != null;
    } catch (e) { return false; }
  }

  const TARGET = "zh-CN";
  const INPUT_TARGET = "en";
  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT", "OPTION", "HEAD", "CODE", "PRE", "KBD", "SAMP", "IFRAME", "SVG", "VIDEO", "AUDIO", "CANVAS", "MATH", "RUBY", "RP", "RT", "FONT"]);
  const SKIP_SELECTORS = "wt-translated, [contenteditable=true], [role=dialog] [aria-modal=true], .ytp-caption-segment, #wt-panel, #wt-toast, code, pre, kbd, samp, svg, math, mat-icon, .material-icons, .material-symbols-outlined, .material-symbols-rounded, .notranslate, [translate=no], [aria-hidden=true]";
  // white-space:pre* 环境下含换行的文本(代码/编辑器/ASCII 图)保持原样,避免换行缩进丢失
  const wsCache = new WeakMap();
  function isPreFormatted(p) {
    let v = wsCache.get(p);
    if (v === undefined) {
      try { v = /^(pre|pre-wrap)/.test(window.getComputedStyle(p).whiteSpace); } catch (e) { v = false; }
      wsCache.set(p, v);
    }
    return v;
  }

  let pageEnabled = false;
  let sidebarVisible = false;
  const originals = new WeakMap();

  // ============ 状态与错误记录(调试侧边栏数据源) ============
  const stats = {
    enabled: false,
    toggles: 0,
    nodesTranslated: 0,
    requests: 0,
    failedBatches: 0,
    lastAction: "尚未操作",
    lastError: "",
    keys: [],
    logs: [],
  };
  function log(msg) {
    stats.logs.push(new Date().toLocaleTimeString() + " " + msg);
    if (stats.logs.length > 60) stats.logs.shift();
  }
  function recordKey(k) {
    stats.keys.push(k);
    if (stats.keys.length > 30) stats.keys.shift();
  }

  // ============ 翻译引擎(经 background,规避 CORS;含 429 退避) ============
  function translateTexts(texts, to) {
    stats.requests += 1;
    return new Promise((resolve) => {
      let settled = false;
      let viaBg = false;
      let viaDirect = false;
      const done = (v, via) => {
        if (settled) return;
        settled = true;
        if (via === "bg") viaBg = true;
        if (via === "direct") viaDirect = true;
        resolve(v);
      };
      // 通道A:background(Google → 必应 → MyMemory)
      try {
        chrome.runtime.sendMessage({ type: "wt-translate", texts, to }, (resp) => {
          const results = (resp && resp.results) || [];
          if (resp && resp.error) {
            stats.failedBatches += 1;
            stats.lastError = resp.error;
            log("后台通道失败: " + resp.error);
          }
          done(results, "bg");
        });
      } catch (e) {
        log("后台消息异常: " + e);
        done([], "bg");
      }
      // 通道B:content 直连 MyMemory(延迟 8s 让后台先跑;并发 3,避免 429 风暴)
      setTimeout(() => {
        if (settled) return; // 后台已返回,跳过直连
        (async () => {
          try {
            const out = new Array(texts.length);
            let ok = 0;
            let idx = 0;
            async function worker() {
              while (idx < texts.length) {
                const i = idx++;
                try {
                  const src = detectSrcLang(texts[i]);
                  if (!src) return; // 无法检测源语言,交给 Google 通道
                  const r = await fetch(
                    "https://api.mymemory.translated.net/get?q=" + encodeURIComponent(texts[i].slice(0, 450)) +
                    "&langpair=" + src + "|" + (to === "en" ? "en" : "zh-CN")
                  );
                  if (r.ok) {
                    const data = await r.json();
                    const tr = (data && data.responseData && data.responseData.translatedText) || "";
                    if (tr && !isBadResult(tr, texts[i])) { out[i] = tr; ok += 1; }
                  }
                } catch (e) { /* 单条失败 */ }
              }
            }
            await Promise.all([worker(), worker(), worker()]);
            if (ok > 0) {
              stats.lastError = "";
              log("直连通道完成 " + ok + "/" + texts.length);
              done(out, "direct");
            }
          } catch (e) { /* 通道B失败 */ }
        })();
      }, 8000);
      setTimeout(() => done([], "timeout"), 120000);
    });
  }

  function isMostlyChinese(text) {
    const cn = (text.match(/[\u4e00-\u9fff]/g) || []).length;
    const en = (text.match(/[A-Za-z]/g) || []).length;
    return cn > 0 && cn >= en;
  }
  function isSkippable(text) {
    return /^[\d\s.,:%+\-()\/\\:]+$/.test(text);
  }
  function isBadResult(tr, orig) {
    if (!tr || !tr.trim()) return true;
    const t = tr.trim();
    if (t.length > 30 && /MYMEMORY WARNING|QUOTA|ALL AVAILABLE FREE|HTTP \d{3}|EXCEPTION|INVALID SOURCE/i.test(t)) return true;
    if (t === orig && orig.length > 20) return true;
    if (orig.length > 10 && t.length > orig.length * 8) return true;
    return false;
  }
  // 繁体/粤语检测:繁体或粤语中文需要转简体
  const TRAD_CHARS = "體們說這門時國學書東來見對後會問點電號車長頭語裡開當發還進過媽覺鐘遠張萬兩邊親銀錢員與華風雙應樣讓幾從種際麗愛現產義習燈寫讀講話聽請謝護轉輕鬆處灣臺灣";
  const CANT_CHARS = "乜嘢嘅咁喺唔佢係啲冇哋嚟畀攞搵睇講傾食飲瞓返咗啦嘞";
  function hasTraditional(t) { for (const c of TRAD_CHARS) if (t.includes(c)) return true; return false; }
  function hasCantonese(t) { for (const c of CANT_CHARS) if (t.includes(c)) return true; return false; }
    function detectSrcLang(t) {
    if (hasCantonese(t)) return "zh-HK";
    if (hasTraditional(t)) return "zh-TW";
    if (/[぀-ヿ]/.test(t)) return "ja"; // 假名优先(日文常混汉字)
    if (/[가-힯]/.test(t)) return "ko";
    if (/[一-鿿]/.test(t)) return "zh-CN";
    if (/[A-Za-z]{4,}/.test(t)) return "en"; // 拉丁文本默认英文(MyMemory 需要具体源语言)
    return null;
  }

  // ============ 文本节点收集(含 shadow DOM) ============
  function walkCollect(root, into, filterFn) {
    try {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          const t = (node.nodeValue || "").trim();
          if (!t) return NodeFilter.FILTER_REJECT;
          const p = node.parentElement;
          if (!p) return NodeFilter.FILTER_REJECT;
          if (SKIP_TAGS.has(p.tagName)) return NodeFilter.FILTER_REJECT;
          // 祖先级跳过:代码高亮 token 的直接父是 span,必须查整条祖先链(pre>code>span)
          if (p.closest && p.closest(SKIP_SELECTORS)) return NodeFilter.FILTER_REJECT;
          // pre 格式化环境且含换行(代码块/编辑器)不翻译,避免排版塌陷
          if (t.includes("\n") && isPreFormatted(p)) return NodeFilter.FILTER_REJECT;
          if (filterFn && !filterFn(t)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        },
      });
      while (walker.nextNode()) into.push(walker.currentNode);
    } catch (e) { /* noop */ }
  }

  function collectTranslateNodes(root) {
    const into = [];
    walkCollect(root, into, (t) => (!isMostlyChinese(t) || hasTraditional(t) || hasCantonese(t)) && !isSkippable(t));
    return into;
  }
  function collectRestoreNodes(root) {
    const into = [];
    walkCollect(root, into, null);
    return into;
  }
  function collectShadowNodes(into, translateMode) {
    try {
      for (const el of document.querySelectorAll("*")) {
        if (el.shadowRoot) {
          walkCollect(el.shadowRoot, into, translateMode ? (t) => (!isMostlyChinese(t) || hasTraditional(t) || hasCantonese(t)) && !isSkippable(t) : null);
        }
      }
    } catch (e) { /* noop */ }
  }

  // ============ 全页翻译 / 还原 ============
  async function translatePage() {
    const nodes = collectTranslateNodes(document);
    collectShadowNodes(nodes, true);
    if (!nodes.length) {
      stats.lastAction = "无可翻译文本";
      log("无可翻译文本");
      return;
    }
    stats.lastAction = "翻译中: " + nodes.length + " 个文本节点";
    log("开始翻译 " + nodes.length + " 节点");
    let done = 0;
    const CHUNK = 100; // 增量:每块独立应用,避免长时间无反馈
    for (let c = 0; c < nodes.length; c += CHUNK) {
      const chunk = nodes.slice(c, c + CHUNK);
      const texts = chunk.map((n) => n.nodeValue.trim());
      const results = await translateTexts(texts, TARGET);
      if (!pageEnabled) return; // 翻译期间被关闭,放弃应用(避免覆盖还原)
      chunk.forEach((node, i) => {
        const tr = results[i];
        if (!tr || !tr.trim() || isBadResult(tr, node.nodeValue)) return;
        if (!originals.has(node)) originals.set(node, node.nodeValue);
        node.nodeValue = tr;
        fadeNode(node);
        done += 1;
      });
      stats.nodesTranslated = done;
      stats.lastAction = "翻译中 " + done + "/" + nodes.length;
    }
    stats.lastAction = "翻译完成: " + done + "/" + nodes.length;
    log("翻译完成 " + done + "/" + nodes.length);
  }

  function restorePage() {
    const nodes = collectRestoreNodes(document);
    collectShadowNodes(nodes, false);
    let done = 0;
    nodes.forEach((node) => {
      if (originals.has(node)) {
        node.nodeValue = originals.get(node);
        originals.delete(node);
        done += 1;
      }
    });
    document.querySelectorAll("[wt-translated]").forEach((el) => el.removeAttribute("wt-translated"));
    stats.lastAction = "已还原 " + done + " 节点";
    log("还原 " + done + " 节点");
  }

  // 状态同步:广播带目标状态,所有 frame 一致,避免反复 toggle 闪烁
  function applyState(enabled) {
    if (pageEnabled === enabled) return;
    pageEnabled = enabled;
    stats.enabled = enabled;
    stats.toggles += 1;
    // 同步状态到所有 frame(iframe 重载后也能对齐)
    try { chrome.runtime.sendMessage({ type: "wt-sync-state", enabled }); } catch (e) { /* noop */ }
    if (pageEnabled) {
      translatePage(); // 调试面板不再自动弹出,需要时按 Alt+T 手动打开
      toast("翻译已开启");
    } else {
      restorePage();
      toast("已还原原文");
    }
  }

  // ============ iframe 广播(postMessage 树递归,跨域通用) ============
  let lastMsgId = "";
  function relayToggle(enabled, id) {
    const payload = { type: "wt-toggle", id, enabled };
    for (let i = 0; i < window.frames.length; i++) {
      try { window.frames[i].postMessage(payload, "*"); } catch (e) { /* noop */ }
    }
    if (window.parent && window.parent !== window) {
      try { window.parent.postMessage(payload, "*"); } catch (e) { /* noop */ }
    }
  }
  function requestToggle() {
    const id = Date.now() + "-" + Math.random().toString(36).slice(2, 8);
    lastMsgId = id; // 防止广播回环(子帧转发回来的消息被再次处理)
    applyState(!pageEnabled);
    relayToggle(pageEnabled, id);
  }

  // ============ 调试侧边栏(Alt+T 开关) ============
  function renderPanel() {
    return `<div style="font-weight:600;font-size:13px;margin-bottom:6px">翻译助手状态</div>
<div>状态:${stats.enabled ? '🟢 已开启' : '⚪ 关闭'} | 触发:${stats.toggles} 次</div>
<div>翻译节点:${stats.nodesTranslated} | 请求:${stats.requests} | 失败批:${stats.failedBatches}</div>
<div>上次操作:${stats.lastAction}</div>
${stats.lastError ? `<div style="color:#ff9090;margin-top:4px">最近错误:${stats.lastError}</div>` : ""}
${stats.keys.length ? `<div style="margin-top:6px;color:#ccc">按键记录:${stats.keys.slice(-12).join(" ")}</div>` : ""}
<div style="margin-top:8px;border-top:1px solid #555;padding-top:6px;color:#bbb">日志(最近 12 条)</div>
${stats.logs.slice(-12).map((l) => `<div style="color:#999;font-size:11px">${l}</div>`).join("")}
<div style="margin-top:8px;color:#777;font-size:11px">Ctrl+F / F2 翻译 · Alt+T 关闭此面板</div>`;
  }
  function showPanel() {
    let panel = document.getElementById("wt-panel");
    if (!panel) {
      panel = document.createElement("div");
      panel.id = "wt-panel";
      panel.style.cssText =
        "position:fixed;top:12px;right:12px;width:340px;max-height:75vh;overflow:auto;background:rgba(28,28,34,.96);color:#eee;z-index:2147483647;border-radius:12px;padding:14px 16px;font:12px/1.7 -apple-system,'Segoe UI','Microsoft YaHei',sans-serif;box-shadow:0 6px 30px rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.08)";
      document.documentElement.appendChild(panel);
    }
    panel.innerHTML = renderPanel() + '<div id="wt-panel-close" style="position:absolute;top:8px;right:12px;cursor:pointer;color:#999;font-size:14px">✕</div>';
    const closeBtn = panel.querySelector("#wt-panel-close");
    if (closeBtn) closeBtn.onclick = () => { sidebarVisible = false; panel.remove(); };
  }
  function toggleSidebar() {
    sidebarVisible = !sidebarVisible;
    if (sidebarVisible) {
      showPanel();
      const t = setInterval(() => {
        if (!sidebarVisible) { clearInterval(t); return; }
        const p = document.getElementById("wt-panel");
        if (p) p.innerHTML = renderPanel();
      }, 1000);
    } else {
      const p = document.getElementById("wt-panel");
      if (p) p.remove();
    }
  }

  // ============ 监听注册 ============
  const seenHotkeyEvents = new WeakSet(); // window+document 双捕获去重(同一次按键只触发一次)
  function hotkeyHandler(e) {
    if (e.repeat) return; // 按住不放的自动重复不触发
    if (!ctxAlive()) {
      window.removeEventListener("keydown", hotkeyHandler, true);
      document.removeEventListener("keydown", hotkeyHandler, true);
      return;
    }
    if (seenHotkeyEvents.has(e)) return;
    const isCtrlF = e.key === "f" && e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey;
    const isF2 = e.key === "F2" && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey;
    const isAltT = e.key === "t" && e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey;
    if (isCtrlF || isF2) {
      seenHotkeyEvents.add(e);
      e.preventDefault();
      e.stopPropagation();
      recordKey("F2/CtrlF");
      requestToggle();
    } else if (isAltT) {
      seenHotkeyEvents.add(e);
      e.preventDefault();
      e.stopPropagation();
      toggleSidebar();
    }
  }
  function registerHotkeys() {
    // document_start 即注册 window 捕获(先于页面脚本),页面在 window 层 stopPropagation 也拦不住
    window.addEventListener("keydown", hotkeyHandler, true);
    document.addEventListener("keydown", hotkeyHandler, true);
  }

  function registerTripleSpace() {
    let spaceCount = 0;
    let firstSpaceAt = 0;
    let lastTriggerAt = 0;
    document.addEventListener(
      "keydown",
      function spaceHandler(e) {
        if (!ctxAlive()) { document.removeEventListener("keydown", spaceHandler, true); return; }
        // 只统计非输入法合成状态下的空格(选字确认的 229/composing 不计,避免打字误触)
        const isSpace = e.key === " " && !e.isComposing && e.keyCode !== 229;
        if (!isSpace) {
          spaceCount = 0;
          return;
        }
        const el = e.target;
        if (!(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement || (el instanceof HTMLElement && el.isContentEditable))) {
          spaceCount = 0;
          return;
        }
        if (e.metaKey || e.ctrlKey || e.altKey) return;
        const now = Date.now();
        // 必须 400ms 内连续按下才算(打字间隔会被重置,杜绝误判)
        if (spaceCount === 0 || now - firstSpaceAt > 400) {
          spaceCount = 1;
          firstSpaceAt = now;
          recordKey("sp1");
          return;
        }
        spaceCount += 1;
        recordKey("sp" + spaceCount);
        if (spaceCount < 3) return;
        spaceCount = 0;
        if (now - lastTriggerAt < 2500) {
          return;
        }
        lastTriggerAt = now;
        e.preventDefault();
        el.classList.add("wt-translating");
        stats.lastAction = "输入框三连空格触发";
        log("三连空格触发");
        toast("正在翻译输入框…");

        let text = "";
        if (el.isContentEditable) text = (el.innerText || "").trim();
        else text = (el.value || "").trim();
        if (!text) {
          stats.lastAction = "输入框为空,忽略";
          return;
        }
        translateTexts([text], INPUT_TARGET).then(([tr]) => {
          el.classList.remove("wt-translating");
          if (!tr || isBadResult(tr, text)) {
            stats.lastAction = "输入框翻译失败";
            log("输入框翻译失败: " + stats.lastError);
            toast("输入框翻译失败");
            return;
          }
          if (el.isContentEditable) {
            el.innerText = tr;
            el.dispatchEvent(new Event("input", { bubbles: true }));
          } else {
            el.value = tr;
            try { el.setSelectionRange(tr.length, tr.length); } catch (e2) { /* noop */ }
            el.dispatchEvent(new Event("input", { bubbles: true }));
          }
          stats.lastAction = "输入框已翻译为英文";
          log("输入框翻译完成");
          toast("已翻译为英文");
        });
      },
      true
    );
  }

  function registerRuntime() {
    try {
      chrome.runtime.onMessage.addListener((msg) => {
        if (!ctxAlive()) return;
        if (msg && msg.type === "wt-sidebar") {
          if (window.top === window) toggleSidebar(); // 面板只在顶层 frame 弹出
        } else if (msg && msg.type === "wt-state") {
          applyState(!!msg.enabled);
        } else if (msg && msg.type === "wt-toggle-request") {
          // 图标点击:由顶层 frame 统一决策,避免各 frame 各自翻转导致状态不一致
          if (window.top === window) requestToggle();
        }
      });
    } catch (e) { /* noop */ }
  }

  function registerMessage() {
    window.addEventListener("message", function msgHandler(e) {
      if (!ctxAlive()) { window.removeEventListener("message", msgHandler); return; }
      const m = e.data;
      if (m && m.type === "wt-toggle") {
        if (m.id === lastMsgId) return;
        lastMsgId = m.id;
        applyState(!!m.enabled);
        relayToggle(!!m.enabled, m.id);
      }
    });
  }

  // ============ 动态内容 ============
  let mo = null;
  function ensureObserver() {
    if (mo) return;
    mo = new MutationObserver(() => {
      if (!ctxAlive()) { try { mo.disconnect(); } catch (e) { /* noop */ } mo = null; return; }
      if (!pageEnabled) return;
      const nodes = collectTranslateNodes(document);
      collectShadowNodes(nodes, true);
      const pending = nodes.filter((n) => !originals.has(n));
      if (!pending.length) return;
      const texts = pending.map((n) => n.nodeValue.trim());
      translateTexts(texts, TARGET).then((results) => {
        if (!pageEnabled) return;
        pending.forEach((node, i) => {
          const tr = results[i];
          if (!tr || !tr.trim()) return;
          if (!originals.has(node)) originals.set(node, node.nodeValue);
          node.nodeValue = tr;
          stats.nodesTranslated += 1;
        });
      });
    });
    mo.observe(document, { childList: true, subtree: true, characterData: true });
    const shadowTimer = setInterval(() => {
      if (!ctxAlive()) { clearInterval(shadowTimer); return; }
      if (!pageEnabled) return;
      try {
        for (const el of document.querySelectorAll("*")) {
          if (el.shadowRoot && !el.shadowRoot.__wtSeen) {
            el.shadowRoot.__wtSeen = true;
            const nodes = [];
            walkCollect(el.shadowRoot, nodes, (t) => (!isMostlyChinese(t) || hasTraditional(t) || hasCantonese(t)) && !isSkippable(t));
            const pending = nodes.filter((n) => !originals.has(n));
            if (!pending.length) continue;
            const texts = pending.map((n) => n.nodeValue.trim());
            translateTexts(texts, TARGET).then((results) => {
              pending.forEach((node, i) => {
                const tr = results[i];
                if (!tr || !tr.trim()) return;
                if (!originals.has(node)) originals.set(node, node.nodeValue);
                node.nodeValue = tr;
                stats.nodesTranslated += 1;
              });
            });
          }
        }
      } catch (e) { /* noop */ }
    }, 1500);
  }

  // ============ 轻量提示 toast(只在顶层显示,替代面板作为操作反馈) ============
  function toast(msg) {
    try {
      if (window.top !== window) return;
      let el = document.getElementById("wt-toast");
      if (!el) {
        el = document.createElement("div");
        el.id = "wt-toast";
        el.style.cssText =
          "position:fixed;bottom:28px;left:50%;transform:translateX(-50%);background:rgba(32,33,36,.92);color:#fff;" +
          "padding:8px 18px;border-radius:20px;font:13px/1.6 -apple-system,'Segoe UI','Microsoft YaHei',sans-serif;" +
          "z-index:2147483647;pointer-events:none;opacity:0;transition:opacity .25s ease";
        (document.body || document.documentElement).appendChild(el);
      }
      el.textContent = msg;
      el.style.opacity = "1";
      clearTimeout(el.__wtT);
      el.__wtT = setTimeout(() => { el.style.opacity = "0"; }, 1600);
    } catch (e) { /* noop */ }
  }

  // ============ 翻译渐变效果 ============
  function injectStyle() {
    try {
      if (document.getElementById("wt-style")) return;
      const st = document.createElement("style");
      st.id = "wt-style";
      st.textContent =
        ".wt-fade-in{animation:wtFadeIn .5s ease}.wt-translating{opacity:.6;transition:opacity .25s ease}" +
        "@keyframes wtFadeIn{from{opacity:.2}to{opacity:1}}";
      (document.head || document.documentElement).appendChild(st);
    } catch (e) { /* noop */ }
  }
  function fadeNode(node) {
    try {
      const p = node.parentElement;
      if (!p) return;
      p.classList.remove("wt-fade-in");
      void p.offsetWidth;
      p.classList.add("wt-fade-in");
    } catch (e) { /* noop */ }
  }

  // ============ 启动(延迟:兼容 doc.write 替换 document 的 iframe) ============
  function init() {
    injectStyle();
    registerHotkeys();
    registerTripleSpace();
    registerMessage();
    registerRuntime();
    ensureObserver();
    log("插件已加载");
  }
  let booted = false;
  function boot() {
    if (booted) return true;
    try {
      if (document.documentElement && document.readyState !== "loading") {
        booted = true;
        init();
        return true;
      }
    } catch (e) { /* noop */ }
    return false;
  }
  if (!boot()) {
    document.addEventListener("DOMContentLoaded", () => boot(), { once: true });
    // 不设时间上限:极慢站点 DOMContentLoaded 晚于 15s 也能补上监听
    const t = setInterval(() => { if (boot()) clearInterval(t); }, 120);
  }
})();
